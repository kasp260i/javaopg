import java.util.Scanner;

public class opgave {
	
	public static int talet = 0;
	public static int talto = 0;   
	public static int skriv = 0;
	public static int svar = 0;
	public static int rigtige = 0;
	public static int valgselv =0;
	public static int diff =0;


	
	  public static void main(String[] args) { 
		  
		  Scanner scan = new Scanner(System.in);
		    double valgselv;
		 
		    System.out.print("Vælg sværhedsgrad mellem 1, 2 og 3");
		   valgselv = scan.nextDouble();
		   
		   if(valgselv==1) {
			   diff += 100;
			   Valgselv(args);
		   } else if(valgselv==1) {
			   diff+=200;
			   Valgselv(args);
		   } else if (valgselv==3) {
			   diff+=200;
			   Valgselv(args);
		   } else {
			   System.out.println("Du valgte ikke en gyldig værdi, prøv igen");
			   main(args);
		   }
	}

	  public static void Valgselv(String[] args) {

	    
	    talet = (int)(Math.floor(Math.random() * diff));
	    talto = (int)(Math.floor(Math.random() * diff));
	    svar = talet-talto;
	    svaret(args);
	}


	public static void svaret(String[] args) {
		Scanner scan = new Scanner(System.in);
	    System.out.print("Hvad er " + talet + " - " + talto + " ? ");
	    double skriv;
	 
	    System.out.print("Skriv svaret:");
	    skriv = scan.nextDouble();


	if(svar==skriv){
	System.out.println("RIGTIGT!"); 
	rigtige += 1;
	System.out.println("Du har svaret rigtigt " + rigtige + " gange"); 
	Valgselv(args);

	} else{
	    System.out.println("Foerkert, Du svarede rigtigt "+ rigtige + " gange. Prøv forfra");
	    rigtige = 0;
	    diff = 0;
	    main(args);
	}

	}

	}