import java.util.Scanner;

public class opgave {
	

	//Opstiller en masse globale variabler
	public static int talet = 0;
	public static int talto = 0;   
	public static int skriv = 0;
	public static int svar = 0;
	public static int rigtige = 0;
	public static int valgselv =0;
	public static int diff =0;


	
	  public static void main(String[] args) {   //Metoden herdder main fordi den startes først
		  
		  Scanner scan = new Scanner(System.in);  //En "Scanner" som er fra java utils som er importet i starten
		    double valgselv;
		 
		    System.out.print("Vælg sværhedsgrad mellem 1, 2 og 3"); //Konsollen skriver at man skal vælge sværhedsgrad
		   valgselv = scan.nextDouble(); //variablen "valgselv" bliver 
		   
		   //Opstiller en masse if-statements
		   if(valgselv==1) { 
			   diff += 100; //Vi valgte at kalde sværhedsgraden for "Diff" altså difficulty fordi man ikke kunne skrive æ
			   Valgselv(args);
		   } else if(valgselv==1) {
			   diff+=200;
			   Valgselv(args);
		   } else if (valgselv==3) {
			   diff+=200;
			   Valgselv(args);
		   } else {
			   System.out.println("Du valgte ikke en gyldig værdi, prøv igen"); //Skriver man skrev forkert hvis der ikke bliver skrevet 1,2 eller 4
			   main(args); //Smider dig tilbage til start funktionen
		   }
	}

	  public static void Valgselv(String[] args) { //Genererer de tal i matematik stykket

	    
	    talet = (int)(Math.floor(Math.random() * diff)); //Laver tal et, som er fra 0 til variablen diff som jo blev ændret i main funktionen
	    talto = (int)(Math.floor(Math.random() * diff));
	    svar = talet-talto;
	    svaret(args); //Kører metoden svaret som stiller dig spørgsmålet
	}


	public static void svaret(String[] args) {
		Scanner scan = new Scanner(System.in);
	    System.out.print("Hvad er " + talet + " - " + talto + " ? "); //Skriver regnestykket
	    double skriv;
	 
	    System.out.print("Skriv svaret:");
	    skriv = scan.nextDouble(); //Igen bliver det skrevet til i konsollen knyttet til skriv varialen


	if(svar==skriv){ //Hvis det rigtige svar er det samme som det spillern skrev så skal den tilføje 1 til variablen "rigtige" samt skrive man har svaret rigtigt og hvor mange gnage man har skrevet ritigt
	System.out.println("RIGTIGT!"); 
	rigtige += 1;
	System.out.println("Du har svaret rigtigt " + rigtige + " gange"); 
	Valgselv(args); //Gører metoden som laver nye tal

	} else{
	    System.out.println("Foerkert, Du svarede rigtigt "+ rigtige + " gange. Prøv forfra"); //Skriver du svarede forkert samt hvad der var rigtigt
	    rigtige = 0;  //Sætter ti 0 rigtige svar
	    diff = 0; //Sætter sværhedsgraden tilbage il 0
	    main(args); //Kører start funktionen igen
	}

	}

	}